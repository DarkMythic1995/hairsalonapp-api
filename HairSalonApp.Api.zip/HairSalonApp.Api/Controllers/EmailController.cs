﻿using HairSalonApp.Api.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Mail;
using System.Net;

namespace HairSalonApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EmailController : ControllerBase
{
    [HttpPost("send")]
    public async Task<IActionResult> SendEmail([FromBody] Appointment appointment)
    {
        try
        {
            if (appointment == null || string.IsNullOrWhiteSpace(appointment.CustomerName))
            {
                return BadRequest(new { Message = "Invalid appointment data" });
            }

            var smtpClient = new SmtpClient("smtp.gmail.com", 587)
            {
                EnableSsl = true,
                Credentials = new NetworkCredential("blueskiessalon@gmail.com", "lgwp vnee tojj eluf") // Replace with App Password
            };

            // Fallback for Papercut testing (uncomment if needed):
            /*
            var smtpClient = new SmtpClient("localhost", 25)
            {
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = true
            };
            */

            var message = new MailMessage
            {
                From = new MailAddress("blueskiessalon@gmail.com"),
                Subject = "New Appointment Request",
                Body = $"Appointment Details:\n" +
                       $"Customer: {appointment.CustomerName}\n" +
                       $"Date: {appointment.AppointmentDate:MM/dd/yyyy}\n" +
                       $"Time: {appointment.AppointmentTime}\n" +
                       $"Service: {appointment.Service}\n" +
                       $"Stylist: {appointment.Stylist}\n" +
                       $"Contact: {appointment.ContactInfo}\n" +
                       $"Status: {appointment.ClientStatus}",
                IsBodyHtml = false
            };
            message.To.Add("blueskiessalon@gmail.com");

            await smtpClient.SendMailAsync(message);
            return Ok(new { Message = "Email sent successfully" });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Message = $"Failed to send email: {ex.Message}" });
        }
    }
}