﻿namespace HairSalonApp.Api.Models
{
    public class Appointment
    {
        public string CustomerName { get; set; }
        public DateTime AppointmentDate { get; set; }
        public string AppointmentTime { get; set; }
        public string Service { get; set; }
        public string Stylist { get; set; }
        public string ContactInfo { get; set; }
        public string ClientStatus { get; set; }
    }
}
